Soorj Modi
0965941
modis@uoguelph.ca
CIS 2520
Assignment 2: Hospital Emergency Room
Simulate the managementof patient cases in a minor emergency medical clinic
using a priority queue.


How to run:
To compile: enter "make" into the command line
To run the executable: enter "make run" into the command line


Assumptions/Limitations:
- Patients arrive at the same time before the beginning of the simulation
